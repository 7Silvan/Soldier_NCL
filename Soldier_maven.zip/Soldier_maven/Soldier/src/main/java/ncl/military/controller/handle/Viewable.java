package ncl.military.controller.handle;

/**
 * @author gural
 * @version 1.0
 *          Date: 13.04.12
 *          Time: 17:02
 */
public interface Viewable {
    String getView();
}
